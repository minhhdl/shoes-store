# shoes-store

How to run this project
At first, you need install NodeJS.
```
git clone https://github.com/minhhdl/shoes-store.git
cd shoes-store
npm install or yarn install
npm run dev or yarn dev
```
To build for production

```
npm run build
npm start
```
