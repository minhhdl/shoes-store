export { default } from '../app/shop';
