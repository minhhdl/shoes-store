export { default } from '../app/product-detail';
