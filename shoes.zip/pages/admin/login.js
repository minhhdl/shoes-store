import { Login } from '../../admin/modules/auth';
export default Login;