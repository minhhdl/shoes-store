import Dashboard from '../../admin/modules/app/dashboard';
export default Dashboard;