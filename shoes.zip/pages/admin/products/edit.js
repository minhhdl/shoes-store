import { AddProduct } from '../../../admin/modules/app/products';
export default AddProduct;