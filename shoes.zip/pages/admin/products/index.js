import { ListProducts } from '../../../admin/modules/app/products';
export default ListProducts;