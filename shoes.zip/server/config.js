const JWTKEY = 'doWnyShoes@#$)(34as#$df*@#&83';

module.exports = {
  JWTKEY,
}