import AppFooter from "./AppFooter";
export default AppFooter;